# Welcome to the Raccoon Cave 🦝

These are **documentation files only**. They do not modify, replace, or access your running Raccoon Radar app or databases.

Place this folder at `Raccoon Radar/Project Records/` (or another location you prefer on your hard drive). Start with `RACCOON_CAVE_PROJECT_LOG.md`; it includes a **RESUME HERE** section for any future chat.

Whenever a new version is completed, update the project log and changelog, and create a fresh backup before installation.

**Current verified user-tested version:** v1.4.1. **Next proposed release:** v1.5 Fundamental & Catalyst Intelligence.
