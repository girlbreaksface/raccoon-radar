# Backup and Recovery — Raccoon Cave

## What to preserve

1. The **entire working App folder**, including every `.py` and `.sqlite3` file.
2. All versioned release ZIP files.
3. All research archive ZIP files and original input datasets.
4. The `Project Records` folder (this documentation).

## Safe manual backup

1. **Close Raccoon Radar completely.** Confirm no Python process is still writing to its databases.
2. In File Explorer, find the folder containing `raccoon_dashboard_v1_2.py` and the SQLite databases.
3. Copy the **entire app folder** into `Raccoon Radar/Backups/YYYY-MM-DD_HHMM_v1.4.1/`. Do not move it.
4. Open the copied folder and verify the three database filenames, if present:
   - `raccoon_history.sqlite3`
   - `raccoon_swing.sqlite3`
   - `raccoon_discovery.sqlite3`
5. Keep an additional copy on a separate physical drive or a reliable cloud backup. **OneDrive synchronization alone is not a versioned backup strategy.**
6. Keep at least the last three known-good copies. Never overwrite the only known-good backup.

## How to restore safely

1. Close the app. **Do not restore over the working folder.**
2. Copy a known-good backup into a new folder named `App_RESTORED_YYYY-MM-DD`.
3. Verify all source files and database files are present.
4. Launch the restored copy and verify research history, research journal and saved UBER case.
5. Switch your shortcut to the restored folder only after checking it. Preserve the previous working folder.

## Avoid these mistakes

- Do not copy a SQLite file while an active app is writing to it; SQLite can also use `-wal` and `-shm` sidecar files.
- Do not put database files in a different folder from the modules that define their paths unless code is explicitly updated.
- Do not confuse a research ZIP export with a full working app backup.
- Do not overwrite the current database with one from an older release.
- Do not treat an empty dashboard at startup as proof that stored data has been deleted; check which app folder is running.
