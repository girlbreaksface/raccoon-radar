# RACCOON CAVE — PROJECT LOG

**Project:** Raccoon Radar / Professor Trash Panda's Market Lab  
**Last updated:** 2026-10-25 (US Eastern)  
**Current verified user-tested release:** v1.4.1  
**Purpose:** Durable handoff notes; keep alongside the application, outside ChatGPT.

## RESUME HERE — FOR A NEW CHAT OR DEVELOPER

We are developing a **Windows Python/Tkinter, read-only market research application**, using local **Moomoo OpenD at 127.0.0.1:11111** for historical quotes. **Never place orders, submit trades, or infer options profitability from underlying ETF moves.** User refers to the project folder as **the Raccoon Cave** and the mascot as **Professor Trash Panda**. The user values careful research, an expanding feature set, and preserving every version and database. Ask for the latest application files and a safe copy of the databases or archive before changing code. Do not assume local file paths from this notebook exist on another machine.

**Last known working state:** v1.4.1 launches; the user confirmed UBER can be saved as a swing research case and **survives restart**. No v1.5 implementation is claimed here. Next planned release: Fundamental & Catalyst Intelligence, beginning with source-attributed SEC filings, financial condition, dilution/cash runway, catalysts, and uncertainty flags; verify data sources and access before implementing.

## PROJECT LAYOUT (suggested)

Raccoon Radar/
- App/ — working release; Python source and runtime SQLite databases
- Backups/ — dated, read-only-to-development copies of databases and releases
- Releases/ — versioned ZIP files; never overwrite old releases
- Research Archives/ — app-produced export archives and datasets
- Project Records/ — this log, changelog, and backup instructions

Actual application may be under `Raccoon Radar/App/raccoon_dashboard_v1_4` in the OneDrive Desktop Raccoon Cave. **Confirm the real path locally before running any script.** Some releases launch through a file still named `raccoon_dashboard_v1_2.py` despite a newer displayed version.

## VERIFIED / REPORTED MILESTONES

| Release | Status | Key work |
|---|---|---|
| v0.3–v0.9 | Historical development | SPY/QQQ completed 1-minute OHLCV research, price-action detector, exploratory setup summaries and export ZIP. |
| v1.0 | Built | Persistent `raccoon_history.sqlite3`, saved history, chronological holdout, weekday study, strict 5-minute per-symbol spacing. |
| v1.1 | User-tested | Append-only research journal, dataset fingerprints, portable research archive. |
| v1.2 | User-tested | Expanding rolling validation and day-level outcomes. |
| v1.2.1 | User-tested | Corrected SQLite backup connection handling on research archive export. |
| v1.3 | User-tested | Swing Opportunity Desk for manual research cases. |
| v1.4 | User-tested | Curated 40-symbol completed-daily-candle volume discovery, 20-prior-session relative volume, persistence and handoff to Swing Desk. |
| v1.4.1 | **User-tested: save and restart persistence passed** | Swing case save controls made accessible; direct save of selected discovery as research case. UBER case saved and survived restart. |

**Historical dataset milestone:** 30 observed trading sessions (2026-09-14 through 2026-10-23), SPY and QQQ, **23,340 one-minute candles**; earlier run reported **11,214 raw detected events**, **6,793 standard-filtered events**, and **3,684 strictly spaced events**. Numbers are historical checkpoints, not a guarantee of the current local database's contents. Earlier research journal reported 13 runs. Revalidate from the local DB before citing new metrics.

**v1.4 scanner checkpoint:** 40 tickers scanned; example relative volumes UBER and GLD 1.24x, XLE 1.21x. These are **historical, time-specific observations**, not current trading signals.

## DATA FILES AND WHAT THEY HOLD

- `raccoon_history.sqlite3`: stored SPY/QQQ candles, research runs, hypothesis notes. Back up first.
- `raccoon_swing.sqlite3`: persistent manual swing research cases, including UBER if present in the user's current copy. Back up first.
- `raccoon_discovery.sqlite3`: stored daily volume discovery results. Back up first.
- Source code: `raccoon_dashboard_v1_2.py` (displayed release can differ from filename), `swing_watchlist.py`, `volume_discovery.py`, `research_journal.py`, `strategy_validation.py`, `validation_intelligence.py`, `setup_detective.py`, `price_action_engine.py`, `performance_intelligence.py`.
- `SAMPLE_SYNTHETIC_CANDLES.csv` is synthetic demonstration data, **not live/historical market evidence**.

SQLite files are stored relative to their corresponding Python modules, so **running different extracted folders may read different databases**. Never replace a newer database with an older copy. Always preserve original databases and copy files only while the app is closed, or use SQLite's online backup API.

## RESEARCH RULES — NONNEGOTIABLE

1. Read-only research; **no broker order endpoints**.
2. Only completed candles in any signal; no lookahead.
3. Underlying SPY/QQQ directional close-to-close movement is **not** 0DTE option P/L; option premium, spreads, fees, theta, execution and exits require separate analysis.
4. Show sample size, observed session coverage, day-level stability and exploratory caveats. SPY/QQQ are correlated; overlapping events aren't independent.
5. Preserve train/test chronology and maintain genuinely fresh out-of-sample data. Prior holdout periods have already been inspected and cannot honestly be called untouched again.
6. No fabricated win rates, buy signals, SEC findings, options flow, or market quotes.
7. Each release: changelog, backup instructions, migration plan, smoke test and rollback path.

## CURRENT PRODUCT AREAS

- **SPY/QQQ Day Trading:** historical event research, validation, day-level outcomes, journal; live alerts are a future goal, not validated or live in this version.
- **Stock Swing Trading:** volume discovery and persistent manually annotated swing cases.
- **Options Swing Trading:** desired future desk for contracts across all premium ranges, with risk-adjusted comparison and separate options data checks; not yet implemented as a verified live options-flow engine.

## ROADMAP (PROPOSED, NOT BUILT)

**v1.5 — Fundamental & Catalyst Intelligence**
- Research selected ticker with SEC EDGAR company filings and provenance: filing type, filing date, accession/link, relevant excerpts, and verification status.
- Assess financing/dilution risk, cash, debt, operating cash flow and runway only when supported by filings; label missing or stale evidence.
- Add catalyst notes and distinguish verified company disclosures from speculative media commentary.
- Store timestamped, source-linked assessments in research case history, preserving manual edits and original source text/link.
- Make the Swing Desk navigable; retain separate research-only workflows.

**Later:** expanded ticker discovery; validated options liquidity/chain intelligence and unusual options activity where licensed data permits; versioned alerts and shadow logging; TradingView parity only after detector rules are frozen and tested.

## OPEN ISSUES / CAUTIONS

- Earlier metadata export once displayed the wrong latest candle date; check/fix if reproducible.
- Encoding artifacts (mojibake such as `â€”`) were visible in some source/UI; clean up in a dedicated, tested patch.
- Layout was crowded; v1.4.1 fixed the Swing Desk save accessibility, but broader navigation redesign remains open.
- Daily volume scanner checks **underlying volume only**, not unusual options volume, liquidity, or buy-worthiness.
- Verify Moomoo quote entitlement, freshness, completion and OpenD quotas for each future data integration.

## NEXT SESSION CHECKLIST

1. Locate the **actual running** v1.4.1 app directory.
2. Close the application and run a dated backup of all three SQLite databases plus source/release ZIP.
3. Reopen the app; verify UBER case exists and research history loads.
4. Review and agree on v1.5 data sources and minimum evidence standards.
5. Implement v1.5 in a **new versioned folder**, never directly over the working copy.
6. Test against synthetic fixtures first, then verify locally with real permitted data.
7. Update this file and `CHANGELOG.md` before shipping.

## CONTINUITY NOTE

This log was reconstructed from available code, prior conversation context and user-reported tests on 2026-10-25. It is **not a substitute for the original app source or SQLite databases**, and it does not assert that the assistant can access the user's hard drive. If details conflict, inspect the local source, the live databases, and dated archives before deciding.

## v1.5 ADDENDUM — BUILT, AWAITING USER TEST
- New SEC fundamentals tab in `raccoon_dashboard_v1_2.py`; SEC submissions and companyfacts, 20 recent filings, selected raw XBRL metrics.
- New `fundamental_intelligence.py`, `raccoon_fundamentals.sqlite3` (created on first use), snapshot/evidence notes.
- v1.4.1 remains last user-tested release until v1.5 confirmed on Windows.
- User-Agent required for SEC; no live news, no options-flow data, no auto buy ratings, no automated cash runway.
- Add fourth SQLite file to backup routine after first use.
