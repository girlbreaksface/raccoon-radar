# Raccoon Radar — Changelog

## v1.4.1 — 2026-10-25 — USER TESTED
- Fixed accessibility of Swing Opportunity Desk save controls.
- Added direct save of a selected Volume Discovery result as a research case.
- User confirmed a UBER research case can be saved and remains after restarting the application.
- No trading/order execution functionality.

## v1.4 — 2026-10-25 — USER TESTED
- Added curated 40-ticker daily unusual-volume discovery via Moomoo OpenD.
- Computed relative daily volume against prior 20 observed sessions.
- Stored discoveries in `raccoon_discovery.sqlite3`.
- Added workflow for investigating discovered tickers in Swing Opportunity Desk.

## v1.3 — 2026-10-25 — USER TESTED
- Added Swing Opportunity Desk and persistent manual case records in `raccoon_swing.sqlite3`.

## v1.2.1 — 2026-10-25 — USER TESTED
- Fixed SQLite archive backup file-lock issue by closing backup connections explicitly.

## v1.2 — 2026-10-25 — USER TESTED
- Added rolling validation and day-level outcomes.

## v1.1 — 2026-10-25 — USER TESTED
- Added append-only research journal, fingerprints, and portable archive.

## v1.0 — 2026-10-25 — BUILT
- Added persistent historical candles, chronological validation and weekday analysis.

## v1.5 — PLANNED, NOT RELEASED
- Fundamental and catalyst intelligence, SEC filing provenance, financing and dilution research.

## v1.5 — SEC fundamentals (2026-10-25)
- SEC filings/companyfacts lookup, dated snapshots and ticker-linked evidence notes in separate SQLite DB.
- No buy signals or automatic financial verdicts. Requires user SEC contact User-Agent and internet.
- Syntax and offline persistence checked; live SEC/Windows GUI not verified.
